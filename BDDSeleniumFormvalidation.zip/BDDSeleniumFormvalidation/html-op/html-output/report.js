$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/pagefactoryform.feature");
formatter.feature({
  "line": 1,
  "name": "Form validation",
  "description": "",
  "id": "form-validation",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "the user is in form",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.the_user_is_in_form()"
});
formatter.result({
  "duration": 93279223,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "name validation",
  "description": "",
  "id": "form-validation;name-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "the name box is empty",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "submit the form with no name",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "display enter name error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.the_name_box_is_empty()"
});
formatter.result({
  "duration": 1149883252,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.submit_the_form_with_no_name()"
});
formatter.result({
  "duration": 124017731,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.display_enter_name_error_message()"
});
formatter.result({
  "duration": 4194259891,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "the user is in form",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.the_user_is_in_form()"
});
formatter.result({
  "duration": 47586,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "city name validation",
  "description": "",
  "id": "form-validation;city-name-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "the city name is empty",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "submit the form with no city",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "display enter city name error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.the_city_name_is_empty()"
});
formatter.result({
  "duration": 1152624333,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.submit_the_form_with_no_city()"
});
formatter.result({
  "duration": 193451761,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.display_enter_city_name_error_message()"
});
formatter.result({
  "duration": 4221417601,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "the user is in form",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.the_user_is_in_form()"
});
formatter.result({
  "duration": 52918,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "password validation",
  "description": "",
  "id": "form-validation;password-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "the password is empty",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "submit the form with no password",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "display enter password error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.the_password_is_empty()"
});
