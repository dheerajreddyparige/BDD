package stepdef;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private FormPageFactory pf;
	private WebDriver wd;
	
	
	@Given("^the user is in form$")
	public void the_user_is_in_form() throws Throwable {
		System.out.println("Fill the detail");
	}

	@When("^the name box is empty$")
	public void the_name_box_is_empty() throws Throwable {

		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");

	}

	@And("^submit the form with no name$")
	public void submit_the_form_with_no_name() throws Throwable {
		pf.setUname("");
		pf.setButton();
	}

	@Then("^display enter name error message$")
	public void display_enter_name_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();

	}

	@When("^the city name is empty$")
	public void the_city_name_is_empty() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");
	}

	@And("^submit the form with no city$")
	public void submit_the_form_with_no_city() throws Throwable {
		pf.setUname("hi");
		pf.setCity("");
		pf.setButton();
	}

	@Then("^display enter city name error message$")
	public void display_enter_city_name_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the password is empty$")
	public void the_password_is_empty() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");
	}

	@And("^submit the form with no password$")
	public void submit_the_form_with_no_password() throws Throwable {
		pf.setUname("hi");
		pf.setCity("chennai");
		pf.setPassword("");
		pf.setButton();
	}

	@Then("^display enter password error message$")
	public void display_enter_password_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the gender is not selected$")
	public void the_gender_is_not_selected() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");
	}

	@And("^submit the form with no gender$")
	public void submit_the_form_with_no_gender() throws Throwable {
		pf.setUname("hi");
		pf.setCity("chennai");
		pf.setPassword("capgemini123");
		//pf.setRadioButton();
		pf.setButton();
	}

	@Then("^display select the gender error message$")
	public void display_select_the_gender_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the language known is not selected$")
	public void the_language_known_is_not_selected() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");
	}

	@And("^submit the form with no language$")
	public void submit_the_form_with_no_language() throws Throwable {
		List<String> list=new ArrayList<String>();
		list.add("no");
		pf.setUname("hi");
		pf.setCity("chennai");
		pf.setPassword("capgemini123");
		pf.setRadioButton(1);
		pf.setCheckBox(list);
		pf.setButton();
	}

	@Then("^display select the language you known error message$")
	public void display_select_the_language_you_known_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the hidden is empty$")
	public void the_hidden_is_empty() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");
	}

	@And("^submit the form with no hidden comments$")
	public void submit_the_form_with_no_hidden_comments() throws Throwable {
		List<String> list=new ArrayList<String>();
		list.add("english");
		list.add("Tamil");
		pf.setUname("hi");
		pf.setCity("chennai");
		pf.setPassword("capgemini123");
		pf.setRadioButton(1);
		pf.setCheckBox(list);
		pf.setTextArea("");
		pf.setButton();
	}

	@Then("^display enter your hidden comments error message$")
	public void display_enter_your_hidden_comments_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	
	@When("^country is not selected$")
	public void country_is_not_selected() throws Throwable {

		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");
	}

	@And("^submit the form without country value$")
	public void submit_the_form_without_country_value() throws Throwable {
		List<String> list=new ArrayList<String>();
		list.add("english");
		list.add("Tamil");
		pf.setUname("hi");
		pf.setCity("chennai");
		pf.setPassword("capgemini123");
		pf.setRadioButton(1);
		pf.setCheckBox(list);
		pf.setTextArea("This is Tamil Nadu");
		pf.select("select");
		pf.setButton();

	}

	@Then("^display select the country error message$")
	public void display_select_the_country_error_message() throws Throwable {

		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	
	
	@When("^the my number is empty$")
	public void the_my_number_is_empty() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");
	}

	@And("^submit the form with no number$")
	public void submit_the_form_with_no_number() throws Throwable {
		List<String> list=new ArrayList<String>();
		list.add("english");
		list.add("Tamil");
		pf.setUname("hi");
		pf.setCity("chennai");
		pf.setPassword("capgemini123");
		pf.setRadioButton(1);
		pf.setCheckBox(list);
		pf.setTextArea("This is Tamil Nadu");
		pf.select("IND");
		pf.setNumber("10");
		pf.setButton();
	}

	@Then("^display enter your number error message$")
	public void display_enter_your_number_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the email box is empty$")
	public void the_email_box_is_empty() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");
	}

	@And("^submit the form with no emailId$")
	public void submit_the_form_with_no_emailId() throws Throwable {
		List<String> list=new ArrayList<String>();
		list.add("english");
		list.add("Tamil");
		pf.setUname("hi");
		pf.setCity("chennai");
		pf.setPassword("capgemini123");
		pf.setRadioButton(1);
		pf.setCheckBox(list);
		pf.setTextArea("This is Tamil Nadu");
		pf.select("IND");
		pf.setNumber("10");
		pf.setEmail("");
		pf.setButton();
	}

	@Then("^display enter your emailId error message$")
	public void display_enter_your_emailId_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}

	@When("^the mobile number is empty$")
	public void the_mobile_number_is_empty() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");

	}

	@And("^submit the form with no mobile number$")
	public void submit_the_form_with_no_mobile_number() throws Throwable {
		List<String> list=new ArrayList<String>();
		list.add("english");
		list.add("Tamil");
		pf.setUname("hi");
		pf.setCity("chennai");
		pf.setPassword("capgemini123");
		pf.setRadioButton(1);
		pf.setCheckBox(list);
		pf.setTextArea("This is Tamil Nadu");
		pf.select("IND");
		pf.setNumber("10");
		pf.setEmail("taj@mail.com");
		pf.setMobilenumber("");
		pf.setButton();
	}

	@Then("^display enter mobile number error message$")
	public void display_enter_mobile_number_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}
	
	@When("^all inputs are correct$")
	public void all_inputs_are_correct() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\THAMIZHANBU\\chromedriver.exe");
    	wd= new ChromeDriver();
    	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	pf=new FormPageFactory(wd);
    	wd.get("D:\\Hema_contents\\java_jee\\STS\\BDDSeleniumFormValidation\\src\\test\\java\\stepdef\\form.html");
	}

	@And("^submit the form with values$")
	public void submit_the_form_with_values() throws Throwable {
		
		
		List<String> list=new ArrayList<String>();
		list.add("english");
		list.add("Tamil");	
		pf.setUname("tamil");
		pf.setCity("chennai");
		pf.setPassword("capgemini123");
		pf.setRadioButton(0);
		pf.setCheckBox(list);
		pf.setTextArea("This is Tamil Nadu");
		pf.select("IND");
		pf.setNumber("10");
		pf.setCity("chennai");
		pf.setEmail("taj@mail.com");
		pf.setMobilenumber("9874566544");
		pf.setButton();
	}

	@Then("^display the success page$")
	public void display_the_success_page() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		wd.close();
	}
	
	
}
